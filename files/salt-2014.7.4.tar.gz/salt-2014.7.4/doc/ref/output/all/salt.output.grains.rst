==================
salt.output.grains
==================

.. automodule:: salt.output.grains
    :members: