====================
salt.output.yaml_out
====================

.. automodule:: salt.output.yaml_out
    :members: