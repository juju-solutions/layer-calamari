================
salt.roster.flat
================

.. automodule:: salt.roster.flat
    :members: