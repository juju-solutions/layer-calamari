.. _all-salt.roster:

===================================
Full list of builtin roster modules
===================================

.. currentmodule:: salt.roster

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    flat
    scan
