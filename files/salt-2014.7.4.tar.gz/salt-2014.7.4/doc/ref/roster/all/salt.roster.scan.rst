================
salt.roster.scan
================

.. automodule:: salt.roster.scan
    :members: