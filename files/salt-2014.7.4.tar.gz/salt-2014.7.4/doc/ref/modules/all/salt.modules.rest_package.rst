=========================
salt.modules.rest_package
=========================

.. automodule:: salt.modules.rest_package
    :members: