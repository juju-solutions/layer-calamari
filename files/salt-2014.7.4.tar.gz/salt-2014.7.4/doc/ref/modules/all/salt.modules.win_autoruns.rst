=========================
salt.modules.win_autoruns
=========================

.. automodule:: salt.modules.win_autoruns
    :members: