==================
salt.modules.event
==================

.. automodule:: salt.modules.event
    :members: