================
salt.modules.reg
================

.. automodule:: salt.modules.reg
    :members:
