=======================
salt.modules.win_system
=======================

.. automodule:: salt.modules.win_system
    :members:
    :exclude-members: get_computer_description, set_computer_description
