================
salt.modules.tls
================

.. automodule:: salt.modules.tls
    :members: