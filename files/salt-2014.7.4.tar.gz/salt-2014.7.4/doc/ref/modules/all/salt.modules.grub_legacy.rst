========================
salt.modules.grub_legacy
========================

.. automodule:: salt.modules.grub_legacy
    :members: