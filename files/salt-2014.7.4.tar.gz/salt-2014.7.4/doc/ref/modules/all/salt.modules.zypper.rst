===================
salt.modules.zypper
===================

.. automodule:: salt.modules.zypper
    :members:
    :exclude-members: list_updates, available_version
