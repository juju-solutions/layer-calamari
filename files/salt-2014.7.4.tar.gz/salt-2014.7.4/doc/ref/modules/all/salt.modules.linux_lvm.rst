======================
salt.modules.linux_lvm
======================

.. automodule:: salt.modules.linux_lvm
    :members: