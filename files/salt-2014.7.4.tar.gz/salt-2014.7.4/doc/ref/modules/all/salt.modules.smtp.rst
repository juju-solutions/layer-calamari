=================
salt.modules.smtp
=================

.. automodule:: salt.modules.smtp
    :members: