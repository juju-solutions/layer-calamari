=======================
salt.modules.osxdesktop
=======================

.. automodule:: salt.modules.osxdesktop
    :members:
