=====================
salt.modules.timezone
=====================

.. automodule:: salt.modules.timezone
    :members: