====================
salt.modules.publish
====================

.. automodule:: salt.modules.publish
    :members: