=====================
salt.modules.mac_user
=====================

.. automodule:: salt.modules.mac_user
    :members: