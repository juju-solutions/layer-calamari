=======================
salt.modules.virtualenv
=======================

.. automodule:: salt.modules.virtualenv_mod
    :members:
