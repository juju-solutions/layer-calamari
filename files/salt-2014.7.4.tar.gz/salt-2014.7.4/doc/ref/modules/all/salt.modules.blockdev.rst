=====================
salt.modules.blockdev
=====================

.. automodule:: salt.modules.blockdev
    :members:
