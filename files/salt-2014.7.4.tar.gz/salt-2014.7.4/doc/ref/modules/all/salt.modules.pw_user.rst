====================
salt.modules.pw_user
====================

.. automodule:: salt.modules.pw_user
    :members: