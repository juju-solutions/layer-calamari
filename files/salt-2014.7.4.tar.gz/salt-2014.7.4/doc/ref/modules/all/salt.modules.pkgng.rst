==================
salt.modules.pkgng
==================

.. automodule:: salt.modules.pkgng
    :members:
    :exclude-members: available_version, delete, purge, update, info
