==================
salt.modules.rsync
==================

.. automodule:: salt.modules.rsync
    :members:
