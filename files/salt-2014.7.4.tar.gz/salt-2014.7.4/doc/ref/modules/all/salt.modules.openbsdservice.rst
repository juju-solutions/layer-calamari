===========================
salt.modules.openbsdservice
===========================

.. automodule:: salt.modules.openbsdservice
    :members: