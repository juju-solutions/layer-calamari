=========================
salt.modules.pkg_resource
=========================

.. automodule:: salt.modules.pkg_resource
    :members: