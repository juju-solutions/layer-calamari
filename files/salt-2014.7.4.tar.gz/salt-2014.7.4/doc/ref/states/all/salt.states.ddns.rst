================
salt.states.ddns
================

.. automodule:: salt.states.ddns
    :members: