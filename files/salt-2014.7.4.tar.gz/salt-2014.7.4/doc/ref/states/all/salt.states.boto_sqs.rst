====================
salt.states.boto_sqs
====================

.. automodule:: salt.states.boto_sqs
    :members: