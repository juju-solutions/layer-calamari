=========================
salt.states.boto_iam_role
=========================

.. automodule:: salt.states.boto_iam_role
    :members: