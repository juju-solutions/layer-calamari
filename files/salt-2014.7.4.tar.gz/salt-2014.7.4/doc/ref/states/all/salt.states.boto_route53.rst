========================
salt.states.boto_route53
========================

.. automodule:: salt.states.boto_route53
    :members: