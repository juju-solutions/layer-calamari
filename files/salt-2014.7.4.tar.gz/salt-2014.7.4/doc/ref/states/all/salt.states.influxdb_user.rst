=========================
salt.states.influxdb_user
=========================

.. automodule:: salt.states.influxdb_user
    :members: