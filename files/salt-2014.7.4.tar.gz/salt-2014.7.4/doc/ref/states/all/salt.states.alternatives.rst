========================
salt.states.alternatives
========================

.. automodule:: salt.states.alternatives
    :members: