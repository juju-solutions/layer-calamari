====================
salt.states.blockdev
====================

.. automodule:: salt.states.blockdev
    :members: