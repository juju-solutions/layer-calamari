====================
salt.states.htpasswd
====================

.. automodule:: salt.states.htpasswd
    :members:
