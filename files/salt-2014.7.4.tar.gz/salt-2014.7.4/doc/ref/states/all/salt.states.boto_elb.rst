====================
salt.states.boto_elb
====================

.. automodule:: salt.states.boto_elb
    :members: