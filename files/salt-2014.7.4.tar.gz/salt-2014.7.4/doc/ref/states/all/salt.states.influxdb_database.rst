=============================
salt.states.influxdb_database
=============================

.. automodule:: salt.states.influxdb_database
    :members: