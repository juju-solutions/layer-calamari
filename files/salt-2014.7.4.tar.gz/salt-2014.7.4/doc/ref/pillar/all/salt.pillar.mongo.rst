=================
salt.pillar.mongo
=================

.. automodule:: salt.pillar.mongo
    :members:
