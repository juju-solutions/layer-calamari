======================
salt.pillar.django_orm
======================

.. automodule:: salt.pillar.django_orm
    :members:
