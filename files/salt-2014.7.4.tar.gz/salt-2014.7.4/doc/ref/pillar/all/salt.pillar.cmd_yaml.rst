====================
salt.pillar.cmd_yaml
====================

.. automodule:: salt.pillar.cmd_yaml
    :members:
