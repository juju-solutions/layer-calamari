======================
salt.pillar.svn_pillar
======================

.. automodule:: salt.pillar.svn_pillar
    :members: