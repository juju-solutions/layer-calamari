=======================
salt.pillar.pillar_ldap
=======================

.. automodule:: salt.pillar.pillar_ldap
    :members:
