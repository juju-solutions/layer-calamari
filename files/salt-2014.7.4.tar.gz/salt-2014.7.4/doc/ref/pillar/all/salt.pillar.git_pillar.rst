======================
salt.pillar.git_pillar
======================

.. automodule:: salt.pillar.git_pillar
    :members: