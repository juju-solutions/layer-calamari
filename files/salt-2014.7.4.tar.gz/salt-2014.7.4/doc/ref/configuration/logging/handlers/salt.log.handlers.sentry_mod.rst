.. automodule:: salt.log.handlers.sentry_mod
