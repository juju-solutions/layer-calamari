====================
salt.runners.winrepo
====================

.. automodule:: salt.runners.winrepo
    :members: