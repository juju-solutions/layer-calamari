=============================
salt.returners.multi_returner
=============================

.. automodule:: salt.returners.multi_returner
    :members: