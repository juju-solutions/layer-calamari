===========================
salt.returners.mongo_return
===========================

.. automodule:: salt.returners.mongo_return
    :members:
