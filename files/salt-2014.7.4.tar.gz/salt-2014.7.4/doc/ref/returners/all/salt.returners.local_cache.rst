==========================
salt.returners.local_cache
==========================

.. automodule:: salt.returners.local_cache
    :members: