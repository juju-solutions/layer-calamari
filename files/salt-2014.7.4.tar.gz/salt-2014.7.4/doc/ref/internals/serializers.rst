================
salt.serializers
================

.. automodule:: salt.utils.serializers

.. automodule:: salt.utils.serializers.json
    :members:

.. automodule:: salt.utils.serializers.yaml
    :members:

.. automodule:: salt.utils.serializers.msgpack
    :members:
