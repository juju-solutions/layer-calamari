=========================
salt.cloud.clouds.proxmox
=========================

.. automodule:: salt.cloud.clouds.proxmox
    :members:
